﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using StudyAppMark2.Models;
using StudyAppMark2.Controllers;

namespace StudyAppMark2.Views.Home
{
    public class NewUserModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
